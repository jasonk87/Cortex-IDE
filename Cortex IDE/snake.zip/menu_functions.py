def start_game():
    print("Starting game...")

def settings():
    print("Settings menu...")

def exit_game():
    print("Exiting game...")