import turtle
import time
import random

# Set up the screen
screen = turtle.Screen()
screen.title('Snake Game')
screen.bgcolor('green')
screen.setup(width=600, height=600)
screen.tracer(0)

# Snake head
head = turtle.Turtle()
head.speed(0)
head.shape('square')
head.color('black')
head.penup()
head.goto(0, 0)
head.direction = 'stop'

# Snake food
food = turtle.Turtle()
food.speed(0)
food.shape('circle')
food.color('red')
food.penup()
food.goto(0, 100)

# Score
score = 0
high_score = 0
speed = 0.1

# Keyboard bindings
screen.listen()
screen.onkey(head.setx, 'Left')
screen.onkey(head.setx, 'Right')
screen.onkey(head.sety, 'Up')
screen.onkey(head.sety, 'Down')

while True:
    screen.update()
    time.sleep(speed)
    head.forward(20)

    # Check for collision with food
    if head.distance(food) < 20:
        food.goto(random.randint(-290, 290), random.randint(-290, 290))
        score += 10
        if score > high_score:
            high_score = score
        # Adjust difficulty
        speed = max(0.05, 0.1 - (score / 100))
        print(f"Difficulty adjusted. Current speed: {speed}")