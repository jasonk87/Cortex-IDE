def main():
    while True:
        choice = display_menu()
        if choice == '1':
            print("Starting game...")
            # Add game initialization code here
            break
        elif choice == '2':
            print("Exiting game.")
            exit()
        else:
            print("Invalid selection. Try again.")