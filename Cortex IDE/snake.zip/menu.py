def show_menu():
    while True:
        print("1. Start")
        print("2. Options")
        print("3. Exit")
        print("4. Multiplayer")
        choice = input("Enter your choice: ")
        if choice == '1':
            start_game()
        elif choice == '2':
            show_options()
        elif choice == '3':
            exit()
        elif choice == '4':
            start_multiplayer()
        else:
            print("Invalid choice")